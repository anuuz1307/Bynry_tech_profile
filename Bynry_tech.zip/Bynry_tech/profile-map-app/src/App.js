// src/App.js

import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import axios from "axios"; // Make sure 'axios' is installed

import ProfileList from "./components/ProfileList";
import Map from "./components/Map";
import ProfileDetails from "./components/ProfileDetails";
import FilterBar from "./components/FilterBar";
import AdminPanel from "./components/AdminPanel";
import Home from "./components/Home";
import "./App.css"; // Import your CSS file

function App() {
  // Replace this with your actual data loading logic
  const [profiles, setProfiles] = React.useState([]);
  const [filteredProfiles, setFilteredProfiles] = React.useState([]);
  const [selectedProfile, setSelectedProfile] = React.useState(null);

  // Load profiles from a JSON file or an API endpoint
  React.useEffect(() => {
    axios.get("/data/profiles.json").then((response) => {
      setProfiles(response.data);
      setFilteredProfiles(response.data);
    });
  }, []);

  // Handle profile selection
  const handleProfileSelect = (profile) => {
    setSelectedProfile(profile);
  };

  // Handle filtering based on user input
  const handleFilterChange = (filterCriteria) => {
    const filtered = profiles.filter((profile) =>
      profile.name.toLowerCase().includes(filterCriteria.toLowerCase())
    );
    setFilteredProfiles(filtered);
  };
  return (
    <Router>
      <div className="App">
        <header>
          <h1>Profile Explorer</h1>
        </header>
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/profile/:id" element={<ProfileDetails profile={selectedProfile} />} />
            <Route path="/admin" element={<AdminPanel />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;

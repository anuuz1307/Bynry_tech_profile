// src/components/ProfileList.js

import React from "react";

function ProfileList({ profiles }) {
  return (
    <div className="profile-list">
      {profiles.map((profile) => (
        <div key={profile.id} className="profile-card">
          {/* Display profile information */}
        </div>
      ))}
    </div>
  );
}

export default ProfileList;

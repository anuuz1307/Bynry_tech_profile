// src/components/FilterBar.js

import React from "react";

function FilterBar({ onFilterChange }) {
  const handleInputChange = (e) => {
    // Update filter criteria
  };

  return (
    <div className="filter-bar">
      <input
        type="text"
        placeholder="Search by name"
        onChange={handleInputChange}
      />
      {/* Add additional filter options */}
    </div>
  );
}

export default FilterBar;

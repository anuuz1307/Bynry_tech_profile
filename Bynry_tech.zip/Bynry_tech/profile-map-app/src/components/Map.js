// src/components/Map.js

import React from "react";
import { GoogleMap, LoadScript, Marker } from "@react-google-maps/api";

function Map({ markers }) {
  // Configure Google Maps options and API key here

  return (
    <LoadScript googleMapsApiKey="YOUR_API_KEY">
      <GoogleMap
        /* Set map options */
      >
        {markers.map((marker) => (
          <Marker
            key={marker.id}
            position={{ lat: marker.lat, lng: marker.lng }}
          />
        ))}
      </GoogleMap>
    </LoadScript>
  );
}

export default Map;

// src/components/AdminPanel.js

import React, { useState } from "react";

function AdminPanel() {
  const [formData, setFormData] = useState({
    name: "",
    photo: "",
    description: "",
    address: "",
    contact: "",
  });

  const handleFormSubmit = (e) => {
    e.preventDefault();
    // Handle form submission to add/edit profiles
  };

  return (
    <div className="admin-panel">
      <h2>Add/Edit Profile</h2>
      <form onSubmit={handleFormSubmit}>
        {/* Form fields for adding/editing profiles */}
      </form>
    </div>
  );
}

export default AdminPanel;
